// ===== GAME STATE =====
let state = {
  subject: '',
  questions: [],
  current: 0,
  correct: 0,
  wrong: 0,
  streak: 0,
  bestStreak: 0,
  answered: false,
  timerInterval: null,
  timeLeft: 1800
};

const LABELS = {
  tamil: '🔤 General Tamil',
  english: '📖 General English',
  gs: '🌍 General Studies',
  aptitude: '🧮 Aptitude & Mental'
};

// ===== START TEST =====
function startTest(subject) {
  clearInterval(state.timerInterval);

  state.subject = subject;
  state.questions = shuffle([...QUESTIONS[subject]]).slice(0, 25);
  state.current = 0;
  state.correct = 0;
  state.wrong = 0;
  state.streak = 0;
  state.bestStreak = 0;
  state.answered = false;
  state.timeLeft = 1800;

  document.getElementById('ssWrap').style.display = 'none';
  document.getElementById('quizScreen').style.display = 'block';
  document.getElementById('gResult').style.display = 'none';

  document.getElementById('gBadge').textContent = LABELS[subject];

  startTimer();
  renderQ();
}

// ===== SHUFFLE =====
function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// ===== TIMER =====
function startTimer() {
  clearInterval(state.timerInterval);
  updateTimerDisplay();
  state.timerInterval = setInterval(() => {
    state.timeLeft--;
    updateTimerDisplay();
    if (state.timeLeft <= 0) {
      clearInterval(state.timerInterval);
      showResult();
    }
  }, 1000);
}

function updateTimerDisplay() {
  const m = Math.floor(state.timeLeft / 60);
  const s = state.timeLeft % 60;
  const el = document.getElementById('gTimer');
  el.textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  el.style.color = state.timeLeft <= 60 ? 'var(--red)' : 'var(--yellow)';
}

// ===== RENDER QUESTION =====
function renderQ() {
  const q = state.questions[state.current];
  const total = state.questions.length;
  const pct = Math.round((state.current / total) * 100);

  document.getElementById('gQNum').textContent = `QUESTION ${state.current + 1} OF ${total}`;
  document.getElementById('gQText').textContent = q.q;
  document.getElementById('gProgTxt').textContent = `Question ${state.current + 1} of ${total}`;
  document.getElementById('gProgPct').textContent = `${pct}%`;
  document.getElementById('gProgFill').style.width = `${pct}%`;

  const fb = document.getElementById('gFb');
  fb.className = 'g-fb';
  fb.textContent = '';

  const next = document.getElementById('gNext');
  next.className = 'g-next';

  state.answered = false;

  const opts = document.getElementById('gOpts');
  opts.innerHTML = '';
  q.opts.forEach((opt, i) => {
    const btn = document.createElement('button');
    btn.className = 'opt-btn';
    btn.textContent = `${String.fromCharCode(65 + i)}. ${opt}`;
    btn.onclick = () => checkAns(i);
    opts.appendChild(btn);
  });
}

// ===== CHECK ANSWER =====
function checkAns(chosen) {
  if (state.answered) return;
  state.answered = true;

  const q = state.questions[state.current];
  const btns = document.querySelectorAll('.opt-btn');
  btns.forEach(b => b.disabled = true);

  const fb = document.getElementById('gFb');
  const next = document.getElementById('gNext');

  if (chosen === q.ans) {
    state.correct++;
    state.streak++;
    if (state.streak > state.bestStreak) state.bestStreak = state.streak;
    btns[chosen].classList.add('correct');
    fb.textContent = '✅ Correct! Well done!';
    fb.className = 'g-fb show correct';
    if (state.streak >= 3) showStreakPopup(state.streak);
  } else {
    state.wrong++;
    state.streak = 0;
    btns[chosen].classList.add('wrong');
    btns[q.ans].classList.add('correct');
    fb.textContent = `❌ Wrong! Correct answer: ${String.fromCharCode(65 + q.ans)}. ${q.opts[q.ans]}`;
    fb.className = 'g-fb show wrong';
  }

  updateStats();
  next.className = 'g-next show';
}

// ===== UPDATE STATS DISPLAY =====
function updateStats() {
  document.getElementById('gC').textContent = state.correct;
  document.getElementById('gW').textContent = state.wrong;
  document.getElementById('gS').textContent = state.streak;
}

// ===== NEXT QUESTION =====
function nextQ() {
  state.current++;
  if (state.current >= state.questions.length) {
    clearInterval(state.timerInterval);
    showResult();
  } else {
    renderQ();
  }
}

// ===== STREAK POPUP =====
function showStreakPopup(n) {
  const el = document.getElementById('sPop');
  document.getElementById('sNum').textContent = n;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2000);
}

// ===== SHOW RESULT =====
function showResult() {
  document.getElementById('quizScreen').style.display = 'none';

  const total = state.questions.length;
  const acc = Math.round((state.correct / total) * 100);
  const pct = (state.correct / total) * 100;

  const grade =
    pct >= 90 ? '🏆 Outstanding!' :
    pct >= 75 ? '🌟 Excellent!' :
    pct >= 60 ? '✅ Good Job!' :
    pct >= 40 ? '📚 Keep Practicing' :
    '💪 Need More Practice';

  const trophy =
    pct >= 90 ? '🏆' :
    pct >= 75 ? '🥇' :
    pct >= 60 ? '🥈' :
    pct >= 40 ? '🥉' : '📚';

  const result = document.getElementById('gResult');
  result.style.display = 'block';

  document.getElementById('rTrophy').textContent = trophy;
  document.getElementById('rTitle').textContent = grade.split(' ').slice(1).join(' ');
  document.getElementById('rSub').textContent = `You completed ${LABELS[state.subject]}`;
  document.getElementById('rScore').textContent = `${state.correct}/${total}`;
  document.getElementById('rC').textContent = state.correct;
  document.getElementById('rW').textContent = state.wrong;
  document.getElementById('rA').textContent = `${acc}%`;
  document.getElementById('rSt').textContent = state.bestStreak;
  document.getElementById('rGrade').textContent = grade;
  document.getElementById('rCircle').style.setProperty('--p', `${pct}%`);
}

// ===== RETRY =====
function retryT() {
  startTest(state.subject);
}

// ===== QUIT =====
function quitG() {
  clearInterval(state.timerInterval);
  goGame();
}
