// ===== NAVIGATION =====
function goHome() {
  showPage('homePage');
}

function goDash() {
  showPage('dashPage');
}

function goGame() {
  showPage('gamePage');
  document.getElementById('ssWrap').style.display = 'block';
  document.getElementById('quizScreen').style.display = 'none';
  document.getElementById('gResult').style.display = 'none';
}

function showPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

// ===== DASHBOARD SECTION SWITCH =====
function switchSection(idx) {
  document.querySelectorAll('.db-section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.db-sidebar-item').forEach(i => i.classList.remove('active'));
  document.querySelectorAll('.db-section')[idx].classList.add('active');
  document.querySelectorAll('.db-sidebar-item')[idx].classList.add('active');
}

// ===== ACCORDION =====
function tog(el) {
  const body = el.nextElementSibling;
  body.classList.toggle('open');
}
